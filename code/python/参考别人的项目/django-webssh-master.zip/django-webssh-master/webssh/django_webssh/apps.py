from django.apps import AppConfig


class DjangoWebsshConfig(AppConfig):
    name = 'django_webssh'
