#!/usr/bin/python3
import os

#输入需要创建的 程序 和 个数
def cp_process(process,number):
    for i in range(number):
        num_name=str(i)+".py"
        y="cp "+process+" "+num_name
        os.system(y)
        os.system("chmod 777 *")

    for i in range(number):
        num_name=str(i)+".py"
        run="./"+num_name+" "+"192.168.201.253"+" 80"+" 10"
        os.system(run)

cp_process('hello.py',3)
