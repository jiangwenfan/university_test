mkdir: cannot create directory ‘tt2’: File exists
