#!/usr/bin/python3
import sys
import time
import os
import subprocess

#print("[title]: test..")
#time.sleep(4)
#a=os.popen("ls -l |wc -l") #替代os.system(),可以获取返回值
#print(type(a.read())) #读取内容
#print("[step 2:] sleep is over!, and you go? input:yes")
#accept=str(input("please input yes or no:"))
#if accept == "yes":
#   print("welcome to !")
#    time.sleep(4)
#print("[end!] thank you use!")
size=os.path.getsize("1.log")
print(size)
